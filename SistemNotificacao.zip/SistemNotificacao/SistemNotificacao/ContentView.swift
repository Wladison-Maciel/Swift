//
//  ContentView.swift
//  SistemNotificacao
//
//  Created by user on 18/11/23.
//


import SwiftUI
import UserNotifications

struct ContentView: View {
    var body: some View {
        VStack {
            
            
            Button("Enviar Notificação") {
                sendNotification()
            }
        }
    }
    
    func sendNotification() {
        let content = UNMutableNotificationContent()
        content.title = "VideoEducaApp"
        content.body = "oie bb, vamos estudar o que hoje!"
        content.sound = UNNotificationSound.default
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        
        let request = UNNotificationRequest(identifier: "notification", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Erro ao agendar notificação: \(error.localizedDescription)")
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
