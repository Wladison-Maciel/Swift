//
//  AppDelegate.swift
//  SistemNotificacao
//
//  Created by user on 18/11/23.
//
import UIKit
import SwiftUI
import UserNotifications

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                print("Permissão concedida para enviar notificações")
            } else if let error = error {
                print("Erro ao solicitar permissão para enviar notificações: \(error.localizedDescription)")
            }
        }

        return true
    }
}
