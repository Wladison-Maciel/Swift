//
//  SistemNotificacaoApp.swift
//  SistemNotificacao
//
//  Created by user on 18/11/23.
//

import SwiftUI

@main
struct SistemNotificacaoApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
