//
//
//
//  Matematica1.swift
//  VideoEduca
//
//  Created by User on 20/10/23.
//

import SwiftUI

struct Matematica1: View {
    var body: some View {
        
        Button(action: {
                    // URL do vídeo do YouTube que você deseja abrir
                    let videoURL = URL(string: "https://youtube.com/playlist?list=PLTPg64KdGgYhjM6MPJ5tqWu2KOBAJ7AF0&si=hkIsZy0PcrmjDpvy")!

                    // Verifica se o aplicativo do YouTube está instalado
                    if UIApplication.shared.canOpenURL(videoURL) {
                        UIApplication.shared.open(videoURL, options: [:], completionHandler: nil)
                    } else {
                        // Se o aplicativo do YouTube não estiver instalado, você pode abrir o link no navegador padrão
                        UIApplication.shared.open(URL(string: "https://youtube.com/playlist?list=PLTPg64KdGgYhjM6MPJ5tqWu2KOBAJ7AF0&si=hkIsZy0PcrmjDpvy")!, options: [:], completionHandler: nil)
                    }
                }) {
                    Text("Assistir no YouTube")
                }
        
    }
}
#Preview {
    Matematica1()
        .preferredColorScheme(.dark)

}
