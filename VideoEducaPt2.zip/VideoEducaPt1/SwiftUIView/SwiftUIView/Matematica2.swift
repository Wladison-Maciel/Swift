//
//  Matematica2.swift
//  VideoEduca
//
//  Created by User on 20/10/23.
//

import SwiftUI

struct Matematica2: View {
    var body: some View {
        NavigationView{
            ScrollView {
                
                VStack{
                    
                    Divider()
                    Text("Suas Video-Aulas aqui!")
                        .font(.system(size: 30))
                        .fontWeight(.bold)
                        .padding(.trailing,11)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white)
                        )
                    Divider()
                    
                    Text("Números Naturais e Inteiros")
                        .font(.system(size: 26))
                        .padding(.trailing, 10)
                        .bold()
                    
                    YTView(ID: "Y_mYgLkuEl4")

                    
                    Divider()
                    
                    Text("Subconjuntos das Partes")
                        .font(.system(size: 26))
                        .padding(.trailing, 10)
                        .bold()
                    
                    YTView(ID: "c5a99sX-Sq8")
                    
                    Text("União e Intersecção")
                        .font(.system(size: 26))
                        .padding(.vertical, 10)
                        .bold()
                    
                    YTView(ID: "Wxm3ugnq9Sw")
                    
                    Text("Diferença e Complementar")
                        .font(.system(size: 26))
                        .padding(.trailing, 10)
                        .bold()
                    
                    YTView(ID: "eZfFpnvudR0")
                }
            }
            .background(Color.red.opacity(0.9))
        }
        
    }
}
    
#Preview {
        Matematica2()
    }
