//
//  Fisica.swift
//  VideoEduca
//
//  Created by User on 20/10/23.
//

import SwiftUI

struct Fisica: View {
    var body: some View {
        Text("Hello, fisica!")
    }
}

#Preview {
    Fisica()
}
