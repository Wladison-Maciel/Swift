//
//  Quimica.swift
//  VideoEduca
//
//  Created by User on 20/10/23.
//

import SwiftUI

struct Quimica: View {
    var body: some View {
        Text("Hello, quimica")
    }
}

#Preview {
    Quimica()
}
