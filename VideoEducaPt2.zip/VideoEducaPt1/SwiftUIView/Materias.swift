//
//  Materias.swift
//  VideoEduca
//
//  Created by User on 20/10/23.
//

import SwiftUI

struct Materias: View {
    @AppStorage("username") var name: String = ""
    
    var body: some View{
        
        NavigationStack {
            VStack {
                
                Text("\(name), o que vamos estudar hoje?")
                    .font(.system(size: 35, weight: .bold))
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
                Spacer()
                
                
                Spacer()
                NavigationLink(destination: Matematica()) {
                    Text("Matemática")
                        .font(.system(size: 25, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.vertical, 45)
                        .frame(width: 270, height: 50)
                        .padding()
                }
                .background(Color.blue)
                .cornerRadius(10)
                
                NavigationLink(destination: Fisica()) {
                    Text("Física")
                        .foregroundColor(.white)
                        .font(.system(size: 25, weight: .bold))
                        .padding(.vertical, 45)
                        .frame(width: 270, height: 50)
                        .padding()
                }
                .background(Color.blue)
                .cornerRadius(10)
                
                NavigationLink(destination: Quimica()) {
                    Text("Química")
                        .foregroundColor(.white)
                        .font(.system(size: 25, weight: .bold))
                        .padding(.vertical, 45)
                        .frame(width: 270, height: 50)
                        .padding()
                }
                .background(Color.blue)
                .cornerRadius(10)
                Spacer()
                Spacer()
                
                
            }
        }

    }
}

#Preview {
    Materias()
}
