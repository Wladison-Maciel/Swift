//
//  SistemNotificacaoApp.swift
//  SistemNotificacao
//
//  Created by user on 18/11/23.
//

import SwiftUI

@main
struct SistemNotificacaoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
