//
//  ContentView.swift
//  SistemNotificacao
//
//  Created by user on 18/11/23.
//


import SwiftUI
import UserNotifications

struct ContentView: View {
    
    @State private var ExercConju = "https://www.exemplo.com" // URL do site desejado
    
    var body: some View {
        
        VStack(spacing: 0) {
            Image("Rectangle1")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 75) // Altura da imagem
                .ignoresSafeArea()
                .overlay{
                    Text("Matemática I")
                        .font(.system(size: 43, weight: .semibold))
                        .foregroundColor(.white)
                        .offset(y: -20)
                }
            
            NavigationView {
                ZStack {
                    
                    Text("Conjuntos")
                        .font(.system(size: 40))
                        .offset(x: 0,y: -290)
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: ExercConju) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Vídeo")
                            .font(.system(size: 28))
                            .frame(width: 145, height: 50)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(100)
                    }
                    .offset(x: -100,y: -210)
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: ExercConju) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Site")
                            .font(.system(size: 28))
                            .frame(width: 145, height: 50)
                            .padding()
                            .background(Color.purple)
                            .foregroundColor(.white)
                            .cornerRadius(100)

                    }
                    
                    .offset(x: 100,y: -210)
                    
                    Image("IconVideos") // Imagem sobreposta (substitua com sua própria imagem)
                    .resizable()
                    .frame(width: 50, height: 50)
                    .offset(x: -150, y: -210)
                    
                    Image("iconExercicios") // Imagem sobreposta (substitua com sua própria imagem)
                    .resizable()
                    .frame(width: 65, height: 65)
                    .offset(x: 55, y: -210)
                    
                  
                    
                }
            }
            //
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
