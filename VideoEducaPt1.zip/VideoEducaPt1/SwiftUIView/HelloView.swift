//
//  HelloView.swift
//  VideoEduca
//
//  Created by User on 20/10/23.
//

import SwiftUI

struct HelloView: View {
    @AppStorage("username") var name: String = ""
    
    var body: some View {
        NavigationStack{
            Text("Seja Bem-Vindo (a), \(name)!!")
                .font(.title3)
                .padding()
            
            NavigationLink(destination: Materias()) {
                Text("Entrar")
                    .font(.system(size: 23, weight: .bold))
                    .foregroundColor(.white)
                    .padding()
                    .frame(width: 150, height: 50)
            }
            .background(Color.blue)
            .cornerRadius(10)
        }
    }
}

#Preview {
    HelloView()
}
